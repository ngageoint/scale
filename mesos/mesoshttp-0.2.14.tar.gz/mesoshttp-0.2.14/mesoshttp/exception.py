

class MesosException(Exception):
    pass


class ACSException(Exception):
    pass